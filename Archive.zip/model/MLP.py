import torch
class MLP(torch.nn.Module):
    def __init__(self, _num_features, _num_classes):
        super(MLP, self).__init__()
        self.fullyconnected1 = torch.nn.Linear(_num_features, 512)
        self.fullyconnected2 = torch.nn.Linear(512, 128)
        self.fullyconnected3 = torch.nn.Linear(128, _num_classes)

    # torch.nn.CrossEntropyLoss includes softmax, so we don't need sigmoid here?
    def forward(self, x):
        # y_pred = torch.sigmoid(self.linear(x))
        
        dout = torch.nn.functional.relu(self.fullyconnected1(x))
        dout = torch.nn.functional.relu(self.fullyconnected2(dout))
        return torch.nn.functional.softmax(self.fullyconnected3(dout))
